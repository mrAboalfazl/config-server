#!/bin/bash

# Update package lists
sudo apt-get update

cd ~
curl -sL https://deb.nodesource.com/setup_16.x -o /tmp/nodesource_setup.sh
sudo bash /tmp/nodesource_setup.sh
sudo apt install nodejs


# Update package lists again
sudo apt-get update

# Install Node.js
sudo apt-get install nodejs -y

cd /home/wvpn/
npm i

./wireguard-install.sh

# Create and edit bvpn.service file
echo "[Unit]
Description=Tunnel WireGuard with udp2raw
After=network.target

[Service]
Type=simple
User=root
ExecStart=sudo node /home/wvpn/main.js
Restart=on-failure
RestartSec=5s

[Install]
WantedBy=multi-user.target" | sudo tee /etc/systemd/system/wvpn.service

# Enable and start bvpn.service
sudo systemctl enable --now wvpn.service

